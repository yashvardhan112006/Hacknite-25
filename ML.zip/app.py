import pandas as pd
import json
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import MinMaxScaler, PolynomialFeatures
from xgboost import XGBRegressor
from sklearn.metrics import r2_score
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV

# Step 1: Load Dataset
df = pd.read_csv("synthetic_solar_data.csv")

# Step 2: Extract Longitude & Latitude from '.geo' Column
def extract_coordinates(geo_str):
    try:
        geo_dict = json.loads(geo_str.replace("'", "\""))  # Convert string to JSON
        return pd.Series([geo_dict["coordinates"][0], geo_dict["coordinates"][1]])  # Extract lon, lat
    except (json.JSONDecodeError, KeyError, TypeError):
        return pd.Series([None, None])  # Handle errors

if ".geo" in df.columns:
    df[["longitude", "latitude"]] = df[".geo"].apply(extract_coordinates)
    df.drop(columns=[".geo"], inplace=True, errors="ignore")

# Step 3: Normalize Data
numerical_cols = ["solar_radiation", "slope", "elevation", "temperature", "precipitation", "longitude", "latitude"]
scaler = MinMaxScaler()
df[numerical_cols] = scaler.fit_transform(df[numerical_cols])

# Step 4: Generate Suitability Score (If Not Present)
if "suitability_score" not in df.columns:
    df["suitability_score"] = (df["solar_radiation"] * 0.4 + 
                                (1 - df["slope"]) * 0.3 + 
                                df["temperature"] * 0.2 + 
                                df["elevation"] * 0.1)

y = df["suitability_score"]
X = df.drop(columns=["suitability_score"])

# Step 5: Feature Engineering - Polynomial Features
poly = PolynomialFeatures(degree=2, interaction_only=True, include_bias=False)
X_poly = poly.fit_transform(X)

# Step 6: Split Data into Train & Test Sets
X_train, X_test, y_train, y_test = train_test_split(X_poly, y, test_size=0.2, random_state=42)

# Step 7: Hyperparameter Tuning using GridSearchCV
param_grid = {
    'n_estimators': [100, 200],
    'learning_rate': [0.05, 0.1],
    'max_depth': [3, 5],
    'subsample': [0.7, 1.0]
}

xgb = XGBRegressor(random_state=42)
grid_search = GridSearchCV(xgb, param_grid, cv=5, scoring='r2', n_jobs=-1)
grid_search.fit(X_train, y_train)
best_model = grid_search.best_estimator_

# Step 8: Train XGBoost Model
best_model.fit(X_train, y_train)

# Step 9: Cross-Validation
cv_scores = cross_val_score(best_model, X_train, y_train, cv=5, scoring='r2')
print(f"Cross-Validation R² Scores: {cv_scores.mean():.2f} ± {cv_scores.std():.2f}")

# Step 10: Predict & Evaluate Model
y_pred = best_model.predict(X_test)
score = r2_score(y_test, y_pred)
print(f"✅ Model R² Score: {score:.2f}")

# Step 11: Feature Importance Analysis
feature_importances = best_model.feature_importances_
feature_names = poly.get_feature_names_out()
importance_df = pd.DataFrame({'Feature': feature_names, 'Importance': feature_importances})
importance_df = importance_df.sort_values(by='Importance', ascending=False)
print("Top Features:")
print(importance_df.head(10))

# Step 12: Save Cleaned Dataset
df.to_csv("solar_suitability_data_cleaned.csv", index=False)
print("✅ Cleaned dataset saved as solar_suitability_data_cleaned.csv")
